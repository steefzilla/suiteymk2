#!/usr/bin/env bash
check_bash_version() {
    local bash_version
    bash_version=$(bash --version | head -n1 | grep -oE '[0-9]+\.[0-9]+' | head -n1)
    if [[ $(echo "$bash_version >= 4.0" | bc -l) -eq 1 ]]; then
        return 0
    else
        echo "Error: Bash version $bash_version is too old. Suitey requires Bash 4.0 or higher." >&2
        echo "Current version: $bash_version" >&2
        echo "Please upgrade Bash to version 4.0 or higher." >&2
        echo "On Ubuntu/Debian: sudo apt-get install bash" >&2
        echo "On macOS with Homebrew: brew install bash" >&2
        return 1
    fi
}
check_docker_installed() {
    if command -v docker >/dev/null 2>&1; then
        return 0
    else
        echo "Error: Docker is not installed. Suitey requires Docker for containerized builds and test execution." >&2
        echo "Please install Docker:" >&2
        echo "  - Ubuntu/Debian: sudo apt-get install docker.io" >&2
        echo "  - CentOS/RHEL: sudo yum install docker" >&2
        echo "  - macOS: Download from https://www.docker.com/products/docker-desktop" >&2
        echo "  - Windows: Download from https://www.docker.com/products/docker-desktop" >&2
        return 1
    fi
}
check_docker_daemon_running() {
    if docker info >/dev/null 2>&1; then
        return 0
    else
        echo "Error: Docker daemon is not running. Suitey requires a running Docker daemon." >&2
        echo "Please start Docker:" >&2
        echo "  - Linux: sudo systemctl start docker (or sudo service docker start)" >&2
        echo "  - macOS/Windows: Start Docker Desktop application" >&2
        echo "  - Or run: sudo dockerd (in a separate terminal)" >&2
        return 1
    fi
}
check_required_directories() {
    local dirs=("src" "tests/bats" "mod")
    local missing_dirs=()
    for dir in "${dirs[@]}"; do
        if [[ ! -d "$dir" ]]; then
            missing_dirs+=("$dir")
        fi
    done
    if [[ ${#missing_dirs[@]} -eq 0 ]]; then
        return 0
    else
        echo "Error: Required directories are missing: ${missing_dirs[*]}" >&2
        echo "Please create the missing directories:" >&2
        for dir in "${missing_dirs[@]}"; do
            echo "  mkdir -p $dir" >&2
        done
        return 1
    fi
}
check_tmp_writable() {
    if [[ -w "/tmp" ]]; then
        return 0
    else
        echo "Error: /tmp directory is not writable. Suitey requires write access to /tmp for temporary files." >&2
        echo "Please check /tmp permissions:" >&2
        echo "  ls -ld /tmp" >&2
        echo "If permissions are incorrect, you may need to:" >&2
        echo "  sudo chmod 1777 /tmp" >&2
        return 1
    fi
}
check_test_dependencies() {
    local deps=("bats")
    local missing_deps=()
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" >/dev/null 2>&1; then
            missing_deps+=("$dep")
        fi
    done
    if [[ ! -f "tests/bats/unit/test_helper/bats-support/load.bash" ]]; then
        missing_deps+=("bats-support")
    fi
    if [[ ! -f "tests/bats/unit/test_helper/bats-assert/load.bash" ]]; then
        missing_deps+=("bats-assert")
    fi
    if [[ ${#missing_deps[@]} -eq 0 ]]; then
        return 0
    else
        echo "Error: Required test dependencies are missing: ${missing_deps[*]}" >&2
        echo "Please install the missing dependencies:" >&2
        for dep in "${missing_deps[@]}"; do
            case "$dep" in
                "bats")
                    echo "  - BATS testing framework:" >&2
                    echo "    Ubuntu/Debian: sudo apt-get install bats" >&2
                    echo "    macOS: brew install bats-core" >&2
                    echo "    Or download from: https://github.com/bats-core/bats-core" >&2
                    ;;
                "bats-support")
                    echo "  - bats-support library:" >&2
                    echo "    git clone https://github.com/bats-core/bats-support.git tests/bats/unit/test_helper/bats-support" >&2
                    ;;
                "bats-assert")
                    echo "  - bats-assert library:" >&2
                    echo "    git clone https://github.com/bats-core/bats-assert.git tests/bats/unit/test_helper/bats-assert" >&2
                    ;;
            esac
        done
        return 1
    fi
}
create_test_file_in_tmp() {
    local test_file="/tmp/suitey_test_file_$$"
    if echo "test content" > "$test_file" 2>/dev/null; then
        rm -f "$test_file"
        return 0
    else
        echo "Error: Cannot create files in /tmp directory. Suitey requires write access to /tmp." >&2
        return 1
    fi
}
verify_filesystem_isolation_principle() {
    local project_dir
    project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    if [[ -d "$project_dir" && -r "$project_dir" ]]; then
        return 0
    else
        echo "Error: Project directory is not accessible. This may indicate permission issues." >&2
        return 1
    fi
}
create_test_directory_in_tmp() {
    local test_dir="/tmp/suitey_test_dir_$$"
    if mkdir "$test_dir" 2>/dev/null; then
        rmdir "$test_dir"
        return 0
    else
        echo "Error: Cannot create directories in /tmp. Suitey requires write access to /tmp for temporary directories." >&2
        return 1
    fi
}
verify_environment_filesystem_isolation() {
    local project_dir
    project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
    local temp_files_before
    temp_files_before=$(find "$project_dir" -name "suitey_*" -type f 2>/dev/null | wc -l)
    check_bash_version >/dev/null 2>&1
    check_docker_installed >/dev/null 2>&1
    check_docker_daemon_running >/dev/null 2>&1
    check_required_directories >/dev/null 2>&1
    check_tmp_writable >/dev/null 2>&1
    check_test_dependencies >/dev/null 2>&1
    local temp_files_after
    temp_files_after=$(find "$project_dir" -name "suitey_*" -type f 2>/dev/null | wc -l)
    if [[ "$temp_files_before" -eq "$temp_files_after" ]]; then
        return 0
    else
        echo "Error: Environment validation functions created files outside /tmp. This violates filesystem isolation." >&2
        return 1
    fi
}
data_get() {
    local data="$1"
    local key="$2"
    if [[ -z "$data" ]] || [[ -z "$key" ]]; then
        return 1
    fi
    local line
    line=$(echo "$data" | grep -m 1 "^${key}=" || true)
    if [[ -z "$line" ]]; then
        echo ""
        return 0
    fi
    local value="${line#${key}=}"
    if [[ "$value" =~ ^\".*\"$ ]]; then
        value="${value#\"}"
        value="${value%\"}"
    elif [[ "$value" =~ ^\'.*\'$ ]]; then
        value="${value#\'}"
        value="${value%\'}"
    fi
    echo "$value"
    return 0
}
data_get_array() {
    local data="$1"
    local array_name="$2"
    local index="$3"
    if [[ -z "$data" ]] || [[ -z "$array_name" ]] || [[ -z "$index" ]]; then
        return 1
    fi
    if ! [[ "$index" =~ ^[0-9]+$ ]]; then
        return 1
    fi
    local key="${array_name}_${index}"
    data_get "$data" "$key"
    return $?
}
data_array_count() {
    local data="$1"
    local array_name="$2"
    if [[ -z "$data" ]] || [[ -z "$array_name" ]]; then
        return 1
    fi
    local count_key="${array_name}_count"
    local count_value
    count_value=$(data_get "$data" "$count_key")
    if [[ -z "$count_value" ]]; then
        echo "0"
        return 0
    fi
    if ! [[ "$count_value" =~ ^[0-9]+$ ]]; then
        echo "0"
        return 0
    fi
    echo "$count_value"
    return 0
}
data_get_array_all() {
    local data="$1"
    local array_name="$2"
    if [[ -z "$data" ]] || [[ -z "$array_name" ]]; then
        return 0
    fi
    local count
    count=$(data_array_count "$data" "$array_name")
    if [[ "$count" == "0" ]]; then
        return 0
    fi
    local i=0
    while [[ $i -lt $count ]]; do
        local element
        element=$(data_get_array "$data" "$array_name" "$i")
        echo "$element"
        i=$((i + 1))
    done
    return 0
}
data_set() {
    local data="$1"
    local key="$2"
    local value="$3"
    if [[ -z "$key" ]]; then
        return 1
    fi
    local filtered_data
    filtered_data=$(echo "$data" | grep -v "^${key}=" || true)
    local cleaned_data=""
    local in_heredoc=false
    local heredoc_start="${key}<<EOF"
    while IFS= read -r line || [[ -n "$line" ]]; do
        local line_prefix="${line%%<<*}"
        if [[ "$line_prefix" == "$key" ]] && [[ "$line" == *"<<"* ]]; then
            in_heredoc=true
            continue
        fi
        if [[ "$in_heredoc" == true ]] && [[ "$line" == "EOF" ]]; then
            in_heredoc=false
            continue
        fi
        if [[ "$in_heredoc" == false ]]; then
            if [[ -n "$cleaned_data" ]]; then
                cleaned_data="${cleaned_data}"$'\n'"${line}"
            else
                cleaned_data="${line}"
            fi
        fi
    done <<< "$filtered_data"
    if [[ -z "$cleaned_data" ]]; then
        cleaned_data="$filtered_data"
    fi
    local escaped_value="$value"
    if [[ "$value" =~ [[:space:]] ]] || [[ "$value" =~ \$ ]] || [[ "$value" =~ \` ]] || [[ "$value" =~ \" ]] || [[ "$value" =~ \\ ]]; then
        escaped_value=$(echo "$value" | sed 's/\\/\\\\/g; s/"/\\"/g')
        escaped_value="\"${escaped_value}\""
    fi
    local result
    if [[ -n "$cleaned_data" ]]; then
        result="${cleaned_data}"$'\n'"${key}=${escaped_value}"
    else
        result="${key}=${escaped_value}"
    fi
    echo "$result"
    return 0
}
data_array_append() {
    local data="$1"
    local array_name="$2"
    local value="$3"
    local count
    count=$(data_array_count "$data" "$array_name")
    if [[ $? -ne 0 ]] || [[ -z "$count" ]]; then
        count=0
    fi
    data=$(data_set "$data" "${array_name}_${count}" "$value")
    local new_count=$((count + 1))
    data=$(data_set "$data" "${array_name}_count" "$new_count")
    echo "$data"
    return 0
}
data_set_array() {
    local data="$1"
    local array_name="$2"
    shift 2  # Remove first two arguments, leaving only values
    local old_count
    old_count=$(data_array_count "$data" "$array_name")
    if [[ "$old_count" -gt 0 ]]; then
        local i=0
        while [[ $i -lt $old_count ]]; do
            data=$(echo "$data" | grep -v "^${array_name}_${i}=" || true)
            i=$((i + 1))
        done
    fi
    data=$(echo "$data" | grep -v "^${array_name}_count=" || true)
    data=$(echo "$data" | grep -v "^$" || true)
    if [[ -z "${data// }" ]]; then
        data=""
    fi
    local index=0
    local values=("$@")
    for value in "${values[@]}"; do
        data=$(data_set "$data" "${array_name}_${index}" "$value")
        index=$((index + 1))
    done
    data=$(data_set "$data" "${array_name}_count" "$index")
    echo "$data"
    return 0
}
data_set_multiline() {
    local data="$1"
    local key="$2"
    local value="$3"
    if [[ -z "$key" ]]; then
        return 1
    fi
    local cleaned_data=""
    local in_heredoc=false
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ "${line%%<<*}" == "$key" ]] && [[ "$line" == *"<<"* ]]; then
            in_heredoc=true
            continue
        fi
        if [[ "$in_heredoc" == true ]] && [[ "$line" == "EOF" ]]; then
            in_heredoc=false
            continue
        fi
        if [[ "$in_heredoc" == true ]]; then
            continue
        fi
        if [[ "$line" =~ ^${key}= ]]; then
            continue
        fi
        if [[ -n "$cleaned_data" ]]; then
            cleaned_data="${cleaned_data}"$'\n'"${line}"
        else
            cleaned_data="${line}"
        fi
    done <<< "$data"
    if [[ -z "${cleaned_data// }" ]]; then
        cleaned_data=""
    fi
    local result
    if [[ -n "$cleaned_data" ]]; then
        result="${cleaned_data}"$'\n'"${key}<<EOF"
    else
        result="${key}<<EOF"
    fi
    if [[ -n "$value" ]]; then
        result="${result}"$'\n'"${value}"
    fi
    result="${result}"$'\n'"EOF"
    echo "$result"
    return 0
}
data_get_multiline() {
    local data="$1"
    local key="$2"
    if [[ -z "$data" ]] || [[ -z "$key" ]]; then
        return 1
    fi
    local in_heredoc=false
    local heredoc_content=""
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ "${line%%<<*}" == "$key" ]] && [[ "$line" == *"<<"* ]]; then
            in_heredoc=true
            continue
        fi
        if [[ "$in_heredoc" == true ]] && [[ "$line" == "EOF" ]]; then
            echo "$heredoc_content"
            return 0
        fi
        if [[ "$in_heredoc" == true ]]; then
            if [[ -n "$heredoc_content" ]]; then
                heredoc_content="${heredoc_content}"$'\n'"${line}"
            else
                heredoc_content="${line}"
            fi
        fi
    done <<< "$data"
    if [[ "$in_heredoc" == true ]]; then
        echo "$heredoc_content"
        return 0
    fi
    data_get "$data" "$key"
    return $?
}
data_validate() {
    local data="$1"
    if [[ -z "$data" ]]; then
        return 0
    fi
    local in_heredoc=false
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ -z "${line// }" ]]; then
            continue
        fi
        if [[ "$line" =~ ^# ]]; then
            continue
        fi
        if [[ "$line" =~ ^\[.*\]$ ]]; then
            continue
        fi
        if [[ "$line" == *"<<"* ]] && [[ "$line" != "="* ]]; then
            in_heredoc=true
            continue
        fi
        if [[ "$line" == "EOF" ]]; then
            in_heredoc=false
            continue
        fi
        if [[ "$in_heredoc" == true ]]; then
            continue
        fi
        if [[ ! "$line" =~ ^[^=]+= ]]; then
            return 1
        fi
    done <<< "$data"
    return 0
}
data_has_key() {
    local data="$1"
    local key="$2"
    if [[ -z "$data" ]] || [[ -z "$key" ]]; then
        return 1
    fi
    if echo "$data" | grep -q "^${key}="; then
        return 0
    fi
    return 1
}
declare -A MODULE_REGISTRY
declare -A MODULE_METADATA
readonly REQUIRED_METHODS=(
    "detect"
    "check_binaries"
    "discover_test_suites"
    "detect_build_requirements"
    "get_build_steps"
    "execute_test_suite"
    "parse_test_results"
    "get_metadata"
)
reset_registry() {
    unset MODULE_REGISTRY MODULE_METADATA
    declare -gA MODULE_REGISTRY
    declare -gA MODULE_METADATA
}
validate_module_interface() {
    for method in "${REQUIRED_METHODS[@]}"; do
        if ! declare -f "$method" >/dev/null 2>&1; then
            return 1
        fi
    done
    return 0
}
validate_module_metadata() {
    local metadata="$1"
    if [[ -z "$metadata" ]]; then
        return 1
    fi
    if ! echo "$metadata" | grep -q "^language="; then
        return 1
    fi
    return 0
}
validate_module_method_signature() {
    local method_name="$1"
    local expected_param_count="$2"
    if ! declare -f "$method_name" >/dev/null 2>&1; then
        return 1
    fi
    return 0
}
validate_module_return_format() {
    local return_value="$1"
    if [[ -z "$return_value" ]]; then
        return 0
    fi
    if echo "$return_value" | grep -q '[{}]'; then
        return 1
    fi
    if ! echo "$return_value" | grep -q "^[^=]*="; then
        if [[ -n "${return_value// }" ]]; then
            return 0
        fi
    fi
    return 0
}
validate_module_interface_complete() {
    local identifier="$1"
    if [[ -z "$identifier" ]]; then
        echo "Error: Module identifier cannot be empty" >&2
        return 1
    fi
    if [[ -z "${MODULE_REGISTRY[$identifier]}" ]]; then
        echo "Error: Module '$identifier' is not registered" >&2
        return 1
    fi
    if ! validate_module_interface; then
        echo "Error: Module '$identifier' does not implement all required methods" >&2
        return 1
    fi
    if declare -f "detect" >/dev/null 2>&1; then
        local sample_result
        sample_result=$(detect "/tmp" 2>/dev/null || echo "")
        if ! validate_module_return_format "$sample_result"; then
            echo "Error: Module '$identifier' method 'detect()' returns invalid format" >&2
            return 1
        fi
    fi
    if declare -f "get_metadata" >/dev/null 2>&1; then
        local metadata
        metadata=$(get_metadata 2>/dev/null || echo "")
        if ! validate_module_return_format "$metadata"; then
            echo "Error: Module '$identifier' method 'get_metadata()' returns invalid format" >&2
            return 1
        fi
    fi
    return 0
}
register_module() {
    local identifier="$1"
    local module_name="$2"
    if [[ -z "$identifier" ]]; then
        echo "Error: Module identifier cannot be empty" >&2
        return 1
    fi
    if [[ -n "${MODULE_REGISTRY[$identifier]}" ]]; then
        echo "Error: Module with identifier '$identifier' is already registered" >&2
        return 1
    fi
    local interface_valid=true
    for method in "${REQUIRED_METHODS[@]}"; do
        if ! declare -f "$method" >/dev/null 2>&1; then
            echo "Error: Module '$identifier' is missing required method '$method'" >&2
            interface_valid=false
        fi
    done
    if [[ "$interface_valid" == false ]]; then
        return 1
    fi
    local metadata=""
    if declare -f "get_metadata" >/dev/null 2>&1; then
        metadata=$(get_metadata)
    else
        echo "Error: Module '$identifier' does not provide get_metadata() method" >&2
        return 1
    fi
    if ! validate_module_metadata "$metadata"; then
        echo "Error: Module '$identifier' has invalid metadata" >&2
        return 1
    fi
    MODULE_REGISTRY[$identifier]="$module_name"
    MODULE_METADATA[$identifier]="$metadata"
    return 0
}
get_module() {
    local identifier="$1"
    if [[ -z "$identifier" ]]; then
        echo "Error: Module identifier cannot be empty" >&2
        return 1
    fi
    if [[ -z "${MODULE_REGISTRY[$identifier]}" ]]; then
        echo "Error: Module '$identifier' not found" >&2
        return 1
    fi
    echo "${MODULE_REGISTRY[$identifier]}"
    return 0
}
get_module_metadata() {
    local identifier="$1"
    if [[ -z "$identifier" ]]; then
        echo "Error: Module identifier cannot be empty" >&2
        return 1
    fi
    if [[ -z "${MODULE_METADATA[$identifier]}" ]]; then
        echo "Error: Module '$identifier' not found" >&2
        return 1
    fi
    echo "${MODULE_METADATA[$identifier]}"
    return 0
}
get_all_modules() {
    if [[ -z "${MODULE_REGISTRY[*]}" ]]; then
        return 0
    fi
    local identifier
    for identifier in "${!MODULE_REGISTRY[@]}"; do
        echo "$identifier"
    done
}
get_modules_by_capability() {
    local capability="$1"
    if [[ -z "$capability" ]]; then
        return 0
    fi
    local identifier
    local modules=""
    for identifier in "${!MODULE_REGISTRY[@]}"; do
        local metadata="${MODULE_METADATA[$identifier]}"
        if [[ -z "$metadata" ]]; then
            continue
        fi
        if echo "$metadata" | grep -q "^capabilities_[0-9]*=${capability}$"; then
            if [[ -z "$modules" ]]; then
                modules="$identifier"
            else
                modules="${modules}"$'\n'"${identifier}"
            fi
        fi
    done
    if [[ -n "$modules" ]]; then
        echo "$modules"
    fi
    return 0
}
get_capabilities() {
    local identifier
    local all_capabilities=""
    for identifier in "${!MODULE_REGISTRY[@]}"; do
        local metadata="${MODULE_METADATA[$identifier]}"
        if [[ -z "$metadata" ]]; then
            continue
        fi
        local capabilities
        capabilities=$(echo "$metadata" | grep "^capabilities_[0-9]*=" | sed 's/^capabilities_[0-9]*=//')
        if [[ -n "$capabilities" ]]; then
            if [[ -z "$all_capabilities" ]]; then
                all_capabilities="$capabilities"
            else
                all_capabilities="${all_capabilities}"$'\n'"${capabilities}"
            fi
        fi
    done
    if [[ -n "$all_capabilities" ]]; then
        echo "$all_capabilities" | sort -u
    fi
    return 0
}
get_modules_by_type() {
    local module_type="$1"
    local identifier
    local modules=""
    if [[ -z "$module_type" ]]; then
        return 0
    fi
    for identifier in "${!MODULE_REGISTRY[@]}"; do
        local metadata="${MODULE_METADATA[$identifier]}"
        if [[ -z "$metadata" ]]; then
            continue
        fi
        local metadata_type
        metadata_type=$(echo "$metadata" | grep "^module_type=" | cut -d'=' -f2 || echo "")
        if [[ "$metadata_type" == "$module_type" ]]; then
            if [[ -z "$modules" ]]; then
                modules="$identifier"
            else
                modules="${modules}"$'\n'"${identifier}"
            fi
        fi
    done
    if [[ -n "$modules" ]]; then
        echo "$modules"
    fi
    return 0
}
get_language_modules() {
    get_modules_by_type "language"
    return 0
}
get_framework_modules() {
    get_modules_by_type "framework"
    return 0
}
get_project_modules() {
    get_modules_by_type "project"
    return 0
}
if [[ -f "src/data_access.sh" ]]; then
    source "src/data_access.sh" 2>/dev/null || true
fi
check_container_environment() {
    local results=""
    local warnings=""
    local docker_command_available="false"
    if command -v docker >/dev/null 2>&1; then
        docker_command_available="true"
    fi
    results="${results}docker_command_available=${docker_command_available}"$'\n'
    local docker_daemon_available="false"
    if [[ "$docker_command_available" == "true" ]]; then
        if docker info >/dev/null 2>&1; then
            docker_daemon_available="true"
        else
            warnings="${warnings}Docker daemon is not running or accessible. Suitey requires Docker for test execution."$'\n'
        fi
    else
        warnings="${warnings}Docker command not found. Install Docker to enable test execution in containers."$'\n'
    fi
    results="${results}docker_daemon_available=${docker_daemon_available}"$'\n'
    local container_operations="false"
    if [[ "$docker_daemon_available" == "true" ]]; then
        if docker run --rm alpine:latest echo "test" >/dev/null 2>&1; then
            container_operations="true"
        else
            warnings="${warnings}Cannot execute basic container operations. Check Docker permissions and configuration."$'\n'
        fi
    fi
    results="${results}container_operations=${container_operations}"$'\n'
    local network_access="false"
    if [[ "$docker_daemon_available" == "true" ]]; then
        if docker pull alpine:latest >/dev/null 2>&1; then
            network_access="true"
            docker rmi alpine:latest >/dev/null 2>&1 || true
        else
            warnings="${warnings}Cannot pull Docker images. Check network connectivity and Docker registry access."$'\n'
        fi
    fi
    results="${results}network_access=${network_access}"$'\n'
    results="${results}docker_available=${docker_daemon_available}"$'\n'
    if [[ -n "$warnings" ]]; then
        local warning_count=0
        while IFS= read -r warning_line || [[ -n "$warning_line" ]]; do
            if [[ -n "$warning_line" ]]; then
                results="${results}docker_warnings_${warning_count}=${warning_line}"$'\n'
                ((warning_count++))
            fi
        done <<< "$warnings"
        results="${results}docker_warnings_count=${warning_count}"$'\n'
    else
        results="${results}docker_warnings_count=0"$'\n'
    fi
    echo "$results"
}
detect_platforms() {
    local project_root="$1"
    if [[ -z "$project_root" ]]; then
        echo "platforms_count=0"
        return 0
    fi
    local modules
    modules=$(get_all_modules 2>/dev/null || echo "")
    if [[ -z "$modules" ]]; then
        echo "platforms_count=0"
        return 0
    fi
    local platforms_count=0
    local platform_index=0
    local results=""
    local container_env_status
    container_env_status=$(check_container_environment 2>/dev/null || echo "")
    if [[ -n "$container_env_status" ]]; then
        results="${results}${container_env_status}"
    fi
    while IFS= read -r module_id || [[ -n "$module_id" ]]; do
        local module_file=""
        if [[ "$module_id" == *"-module" ]]; then
            local language="${module_id%-module}"
            module_file="mod/languages/${language}/mod.sh"
        fi
        if [[ ! -f "$module_file" ]] && [[ "$module_id" == *"-module" ]]; then
            local framework="${module_id%-module}"
            module_file="mod/frameworks/${framework}/mod.sh"
        fi
        if [[ ! -f "$module_file" ]]; then
            continue
        fi
        for method in detect check_binaries discover_test_suites detect_build_requirements get_build_steps execute_test_suite parse_test_results get_metadata; do
            unset -f "$method" 2>/dev/null || true
        done
        source "$module_file" 2>/dev/null || continue
        local detection_result
        detection_result=$(detect "$project_root" 2>/dev/null || echo "")
        if [[ -z "$detection_result" ]]; then
            continue
        fi
        local detected
        if declare -f data_get >/dev/null 2>&1; then
            detected=$(data_get "$detection_result" "detected" || echo "false")
        else
            detected=$(echo "$detection_result" | grep "^detected=" | cut -d'=' -f2 || echo "false")
        fi
        if [[ "$detected" == "true" ]]; then
            local language
            local framework
            local confidence
            if declare -f data_get >/dev/null 2>&1; then
                language=$(data_get "$detection_result" "language" || echo "")
                framework=$(data_get "$detection_result" "frameworks_0" || echo "")
                confidence=$(data_get "$detection_result" "confidence" || echo "low")
            else
                language=$(echo "$detection_result" | grep "^language=" | cut -d'=' -f2 || echo "")
                framework=$(echo "$detection_result" | grep "^frameworks_0=" | cut -d'=' -f2 || echo "")
                confidence=$(echo "$detection_result" | grep "^confidence=" | cut -d'=' -f2 || echo "low")
            fi
            if [[ -z "$language" ]]; then
                echo "Warning: Module '$module_id' detected platform but did not specify language. Skipping platform." >&2
                continue
            fi
            if [[ -n "$results" ]]; then
                results="${results}"$'\n'"platforms_${platform_index}_language=${language}"
            else
                results="platforms_${platform_index}_language=${language}"
            fi
            if [[ -n "$framework" ]]; then
                results="${results}"$'\n'"platforms_${platform_index}_framework=${framework}"
            fi
            results="${results}"$'\n'"platforms_${platform_index}_confidence=${confidence}"
            results="${results}"$'\n'"platforms_${platform_index}_module_id=${module_id}"
            local module_metadata
            if declare -f get_metadata >/dev/null 2>&1; then
                module_metadata=$(get_metadata 2>/dev/null || echo "")
                if [[ -n "$module_metadata" ]]; then
                    while IFS= read -r metadata_line || [[ -n "$metadata_line" ]]; do
                        if [[ -n "$metadata_line" ]]; then
                            results="${results}"$'\n'"platforms_${platform_index}_${metadata_line}"
                        fi
                    done <<< "$module_metadata"
                fi
            fi
            local indicators_count
            if declare -f data_array_count >/dev/null 2>&1; then
                indicators_count=$(data_array_count "$detection_result" "indicators" || echo "0")
            else
                indicators_count=$(echo "$detection_result" | grep "^indicators_count=" | cut -d'=' -f2 || echo "0")
            fi
            results="${results}"$'\n'"platforms_${platform_index}_indicators_count=${indicators_count}"
            local i=0
            while [[ $i -lt "$indicators_count" ]]; do
                local indicator
                if declare -f data_get_array >/dev/null 2>&1; then
                    indicator=$(data_get_array "$detection_result" "indicators" "$i" || echo "")
                else
                    indicator=$(echo "$detection_result" | grep "^indicators_${i}=" | cut -d'=' -f2 || echo "")
                fi
                if [[ -n "$indicator" ]]; then
                    results="${results}"$'\n'"platforms_${platform_index}_indicators_${i}=${indicator}"
                fi
                i=$((i + 1))
            done
            platforms_count=$((platforms_count + 1))
            platform_index=$((platform_index + 1))
        fi
    done <<< "$modules"
    echo "platforms_count=${platforms_count}"
    if [[ -n "$results" ]]; then
        echo "$results"
    fi
    return 0
}
detect() {
    local project_root="$1"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "detected=false"
        echo "confidence=low"
        echo "indicators_count=0"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    local bats_files
    bats_files=$(find "$project_root" -maxdepth 3 -name "*.bats" -type f 2>/dev/null | head -1)
    if [[ -n "$bats_files" ]]; then
        echo "detected=true"
        echo "confidence=high"
        echo "indicators_0=bats_test_files"
        echo "indicators_count=1"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    if [[ -d "$project_root/tests/bats" ]] || [[ -d "$project_root/test/bats" ]]; then
        echo "detected=true"
        echo "confidence=medium"
        echo "indicators_0=bats_test_directory"
        echo "indicators_count=1"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    echo "detected=false"
    echo "confidence=low"
    echo "indicators_count=0"
    echo "language=bash"
    echo "frameworks_0=bats"
    return 0
}
check_binaries() {
    local project_root="$1"
    if command -v bats >/dev/null 2>&1; then
        local bats_version
        bats_version=$(bats --version 2>/dev/null | head -1 || echo "unknown")
        bats_version="${bats_version#bats }"
        echo "available=true"
        echo "binaries_0=bats"
        echo "binaries_count=1"
        echo "versions_bats=$bats_version"
        echo "container_check=false"
    else
        echo "available=false"
        echo "binaries_0=bats"
        echo "binaries_count=1"
        echo "container_check=false"
    fi
    return 0
}
discover_test_suites() {
    local project_root="$1"
    local framework_metadata="$2"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "suites_count=0"
        return 0
    fi
    local suites_count=0
    local suite_index=0
    local results=""
    local test_dirs=("$project_root/tests/bats" "$project_root/test/bats" "$project_root/tests" "$project_root/test")
    for test_dir in "${test_dirs[@]}"; do
        if [[ -d "$test_dir" ]]; then
            local bats_files
            bats_files=$(find "$test_dir" -name "*.bats" -type f 2>/dev/null)
            if [[ -n "$bats_files" ]]; then
                local file_count
                file_count=$(echo "$bats_files" | wc -l)
                if [[ $file_count -gt 0 ]]; then
                    local suite_name
                    suite_name=$(basename "$test_dir")
                    if [[ -z "$results" ]]; then
                        results="suites_${suite_index}_name=${suite_name}"
                    else
                        results="${results}"$'\n'"suites_${suite_index}_name=${suite_name}"
                    fi
                    results="${results}"$'\n'"suites_${suite_index}_framework=bats"
                    results="${results}"$'\n'"suites_${suite_index}_test_files_count=${file_count}"
                    suites_count=$((suites_count + 1))
                    suite_index=$((suite_index + 1))
                    break
                fi
            fi
        fi
    done
    if [[ $suites_count -eq 0 ]]; then
        local bats_files
        bats_files=$(find "$project_root" -maxdepth 3 -name "*.bats" -type f 2>/dev/null)
        if [[ -n "$bats_files" ]]; then
            local file_count
            file_count=$(echo "$bats_files" | wc -l)
            if [[ $file_count -gt 0 ]]; then
                results="suites_0_name=bats_tests"
                results="${results}"$'\n'"suites_0_framework=bats"
                results="${results}"$'\n'"suites_0_test_files_count=${file_count}"
                suites_count=1
            fi
        fi
    fi
    echo "suites_count=${suites_count}"
    if [[ -n "$results" ]]; then
        echo "$results"
    fi
    return 0
}
detect_build_requirements() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "requires_build=false"
    echo "build_steps_count=0"
    echo "build_commands_count=0"
    echo "build_dependencies_count=0"
    echo "build_artifacts_count=0"
    return 0
}
get_build_steps() {
    local project_root="$1"
    local build_requirements="$2"
    echo "build_steps_count=0"
    return 0
}
execute_test_suite() {
    local test_suite="$1"
    local test_image="$2"
    local execution_config="$3"
    echo "exit_code=0"
    echo "duration=0.0"
    echo "execution_method=docker"
    echo "test_command=bats"
    return 0
}
parse_test_results() {
    local output="$1"
    local exit_code="$2"
    if [[ "$exit_code" == "0" ]]; then
        echo "total_tests=0"
        echo "passed_tests=0"
        echo "failed_tests=0"
        echo "skipped_tests=0"
        echo "test_details_count=0"
        echo "status=passed"
    else
        echo "total_tests=0"
        echo "passed_tests=0"
        echo "failed_tests=0"
        echo "skipped_tests=0"
        echo "test_details_count=0"
        echo "status=failed"
    fi
    return 0
}
get_metadata() {
    echo "module_type=framework"
    echo "language=bash"
    echo "frameworks_0=bats"
    echo "frameworks_count=1"
    echo "project_type=shell_script"
    echo "version=0.1.0"
    echo "capabilities_0=testing"
    echo "capabilities_count=1"
    echo "required_binaries_0=bats"
    echo "required_binaries_count=1"
    return 0
}
detect() {
    local project_root="$1"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "detected=false"
        echo "confidence=low"
        echo "indicators_count=0"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    if [[ -f "$project_root/Cargo.toml" ]]; then
        echo "detected=true"
        echo "confidence=high"
        echo "indicators_0=Cargo.toml"
        echo "indicators_count=1"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    echo "detected=false"
    echo "confidence=low"
    echo "indicators_count=0"
    echo "language=rust"
    echo "frameworks_0=cargo"
    return 0
}
check_binaries() {
    local project_root="$1"
    if command -v cargo >/dev/null 2>&1; then
        local cargo_version
        cargo_version=$(cargo --version 2>/dev/null | head -1 || echo "unknown")
        cargo_version="${cargo_version#cargo }"
        echo "available=true"
        echo "binaries_0=cargo"
        echo "binaries_count=1"
        echo "versions_cargo=$cargo_version"
        echo "container_check=false"
    else
        echo "available=false"
        echo "binaries_0=cargo"
        echo "binaries_count=1"
        echo "container_check=false"
    fi
    return 0
}
discover_test_suites() {
    local project_root="$1"
    local framework_metadata="$2"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "suites_count=0"
        return 0
    fi
    local suites_count=0
    local suite_index=0
    local results=""
    if [[ -d "$project_root/src" ]]; then
        local unit_test_files
        unit_test_files=$(find "$project_root/src" -name "*.rs" -type f 2>/dev/null | head -5)
        if [[ -n "$unit_test_files" ]]; then
            local unit_file_count
            unit_file_count=$(echo "$unit_test_files" | wc -l)
            if [[ $unit_file_count -gt 0 ]]; then
                if [[ -z "$results" ]]; then
                    results="suites_${suite_index}_name=unit_tests"
                else
                    results="${results}"$'\n'"suites_${suite_index}_name=unit_tests"
                fi
                results="${results}"$'\n'"suites_${suite_index}_framework=cargo"
                results="${results}"$'\n'"suites_${suite_index}_test_files_count=${unit_file_count}"
                suites_count=$((suites_count + 1))
                suite_index=$((suite_index + 1))
            fi
        fi
    fi
    if [[ -d "$project_root/tests" ]]; then
        local integration_test_files
        integration_test_files=$(find "$project_root/tests" -name "*.rs" -type f 2>/dev/null)
        if [[ -n "$integration_test_files" ]]; then
            local integration_file_count
            integration_file_count=$(echo "$integration_test_files" | wc -l)
            if [[ $integration_file_count -gt 0 ]]; then
                if [[ -z "$results" ]]; then
                    results="suites_${suite_index}_name=integration_tests"
                else
                    results="${results}"$'\n'"suites_${suite_index}_name=integration_tests"
                fi
                results="${results}"$'\n'"suites_${suite_index}_framework=cargo"
                results="${results}"$'\n'"suites_${suite_index}_test_files_count=${integration_file_count}"
                suites_count=$((suites_count + 1))
            fi
        fi
    fi
    echo "suites_count=${suites_count}"
    if [[ -n "$results" ]]; then
        echo "$results"
    fi
    return 0
}
detect_build_requirements() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "requires_build=true"
    echo "build_steps_count=1"
    echo "build_commands_0=cargo build --tests"
    echo "build_commands_count=1"
    echo "build_dependencies_count=0"
    echo "build_artifacts_count=0"
    return 0
}
get_build_steps() {
    local project_root="$1"
    local build_requirements="$2"
    echo "build_steps_count=0"
    return 0
}
execute_test_suite() {
    local test_suite="$1"
    local test_image="$2"
    local execution_config="$3"
    echo "exit_code=0"
    echo "duration=0.0"
    echo "execution_method=docker"
    echo "test_command=cargo test"
    return 0
}
parse_test_results() {
    local output="$1"
    local exit_code="$2"
    if [[ "$exit_code" == "0" ]]; then
        echo "total_tests=0"
        echo "passed_tests=0"
        echo "failed_tests=0"
        echo "skipped_tests=0"
        echo "test_details_count=0"
        echo "status=passed"
    else
        echo "total_tests=0"
        echo "passed_tests=0"
        echo "failed_tests=0"
        echo "skipped_tests=0"
        echo "test_details_count=0"
        echo "status=failed"
    fi
    return 0
}
get_metadata() {
    echo "module_type=framework"
    echo "language=rust"
    echo "frameworks_0=cargo"
    echo "frameworks_count=1"
    echo "project_type=cargo_project"
    echo "version=0.1.0"
    echo "capabilities_0=testing"
    echo "capabilities_1=compilation"
    echo "capabilities_count=2"
    echo "required_binaries_0=cargo"
    echo "required_binaries_count=1"
    return 0
}
detect() {
    local project_root="$1"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "detected=false"
        echo "confidence=low"
        echo "indicators_count=0"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    local bats_files
    bats_files=$(find "$project_root" -maxdepth 3 -name "*.bats" -type f 2>/dev/null | head -1)
    if [[ -n "$bats_files" ]]; then
        echo "detected=true"
        echo "confidence=high"
        echo "indicators_0=bats_test_files"
        echo "indicators_count=1"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    if [[ -d "$project_root/tests/bats" ]] || [[ -d "$project_root/test/bats" ]]; then
        echo "detected=true"
        echo "confidence=medium"
        echo "indicators_0=bats_test_directory"
        echo "indicators_count=1"
        echo "language=bash"
        echo "frameworks_0=bats"
        return 0
    fi
    local sh_files
    sh_files=$(find "$project_root" -maxdepth 2 -name "*.sh" -type f 2>/dev/null | head -1)
    if [[ -n "$sh_files" ]]; then
        if head -1 "$sh_files" 2>/dev/null | grep -q "#!/usr/bin/env bash\|#!/bin/bash"; then
            echo "detected=true"
            echo "confidence=low"
            echo "indicators_0=bash_script_files"
            echo "indicators_count=1"
            echo "language=bash"
            echo "frameworks_0=bats"
            return 0
        fi
    fi
    echo "detected=false"
    echo "confidence=low"
    echo "indicators_count=0"
    echo "language=bash"
    echo "frameworks_0=bats"
    return 0
}
check_binaries() {
    local project_root="$1"
    if command -v bats >/dev/null 2>&1; then
        local bats_version
        bats_version=$(bats --version 2>/dev/null | head -1 || echo "unknown")
        bats_version="${bats_version#bats }"
        echo "available=true"
        echo "binaries_0=bats"
        echo "binaries_count=1"
        echo "versions_bats=$bats_version"
        echo "container_check=false"
    else
        echo "available=false"
        echo "binaries_0=bats"
        echo "binaries_count=1"
        echo "container_check=false"
    fi
    return 0
}
discover_test_suites() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "suites_count=0"
    return 0
}
detect_build_requirements() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "requires_build=false"
    echo "build_steps_count=0"
    echo "build_commands_count=0"
    echo "build_dependencies_count=0"
    echo "build_artifacts_count=0"
    return 0
}
get_build_steps() {
    local project_root="$1"
    local build_requirements="$2"
    echo "build_steps_count=0"
    return 0
}
execute_test_suite() {
    local test_suite="$1"
    local test_image="$2"
    local execution_config="$3"
    echo "exit_code=0"
    echo "duration=0.0"
    echo "execution_method=docker"
    return 0
}
parse_test_results() {
    local output="$1"
    local exit_code="$2"
    echo "total_tests=0"
    echo "passed_tests=0"
    echo "failed_tests=0"
    echo "skipped_tests=0"
    echo "test_details_count=0"
    echo "status=passed"
    return 0
}
get_metadata() {
    echo "module_type=language"
    echo "language=bash"
    echo "frameworks_0=bats"
    echo "frameworks_count=1"
    echo "project_type=shell_script"
    echo "version=0.1.0"
    echo "capabilities_0=testing"
    echo "capabilities_count=1"
    echo "required_binaries_0=bats"
    echo "required_binaries_count=1"
    return 0
}
detect() {
    local project_root="$1"
    if [[ -z "$project_root" ]] || [[ ! -d "$project_root" ]]; then
        echo "detected=false"
        echo "confidence=low"
        echo "indicators_count=0"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    if [[ -f "$project_root/Cargo.toml" ]]; then
        echo "detected=true"
        echo "confidence=high"
        echo "indicators_0=Cargo.toml"
        echo "indicators_count=1"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    if [[ -f "$project_root/Cargo.lock" ]]; then
        echo "detected=true"
        echo "confidence=medium"
        echo "indicators_0=Cargo.lock"
        echo "indicators_count=1"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    if find "$project_root" -maxdepth 2 -name "*.rs" -type f 2>/dev/null | head -1 | grep -q .; then
        echo "detected=true"
        echo "confidence=low"
        echo "indicators_0=rust_source_files"
        echo "indicators_count=1"
        echo "language=rust"
        echo "frameworks_0=cargo"
        return 0
    fi
    echo "detected=false"
    echo "confidence=low"
    echo "indicators_count=0"
    echo "language=rust"
    echo "frameworks_0=cargo"
    return 0
}
check_binaries() {
    local project_root="$1"
    if command -v cargo >/dev/null 2>&1; then
        local cargo_version
        cargo_version=$(cargo --version 2>/dev/null | head -1 || echo "unknown")
        cargo_version="${cargo_version#cargo }"
        echo "available=true"
        echo "binaries_0=cargo"
        echo "binaries_count=1"
        echo "versions_cargo=$cargo_version"
        echo "container_check=false"
    else
        echo "available=false"
        echo "binaries_0=cargo"
        echo "binaries_count=1"
        echo "container_check=false"
    fi
    return 0
}
discover_test_suites() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "suites_count=0"
    return 0
}
detect_build_requirements() {
    local project_root="$1"
    local framework_metadata="$2"
    echo "requires_build=true"
    echo "build_steps_count=1"
    echo "build_commands_0=cargo build --tests"
    echo "build_commands_count=1"
    echo "build_dependencies_count=0"
    echo "build_artifacts_count=0"
    return 0
}
get_build_steps() {
    local project_root="$1"
    local build_requirements="$2"
    echo "build_steps_count=0"
    return 0
}
execute_test_suite() {
    local test_suite="$1"
    local test_image="$2"
    local execution_config="$3"
    echo "exit_code=0"
    echo "duration=0.0"
    echo "execution_method=docker"
    return 0
}
parse_test_results() {
    local output="$1"
    local exit_code="$2"
    echo "total_tests=0"
    echo "passed_tests=0"
    echo "failed_tests=0"
    echo "skipped_tests=0"
    echo "test_details_count=0"
    echo "status=passed"
    return 0
}
get_metadata() {
    echo "module_type=language"
    echo "language=rust"
    echo "frameworks_0=cargo"
    echo "frameworks_count=1"
    echo "project_type=cargo"
    echo "version=0.1.0"
    echo "capabilities_0=testing"
    echo "capabilities_1=compilation"
    echo "capabilities_count=2"
    echo "required_binaries_0=cargo"
    echo "required_binaries_count=1"
    return 0
}
# Main Suitey functionality will be added here

# Exit code constants
# 0 = success
# 1 = tests failed (for future use)
# 2 = suitey error (invalid arguments, internal errors, etc.)
readonly EXIT_SUCCESS=0
readonly EXIT_TESTS_FAILED=1
readonly EXIT_SUITEY_ERROR=2

show_help() {
    cat << 'HELP_EOF'
Suitey v0.1.0 - Cross-platform test runner

Usage: suitey.sh [OPTIONS] [COMMAND]

DESCRIPTION
    Suitey is a cross-platform test runner that automatically detects test suites,
    builds projects, and executes tests in isolated Docker containers.

OPTIONS
    -h, --help          Show this help message and exit
    -v, --version       Show version information and exit

COMMANDS
    (Commands will be implemented in future phases)

EXAMPLES
    suitey.sh --help          Show help information
    suitey.sh --version       Show version information
    suitey.sh                 Show help (default behavior)

For more information, see the Suitey documentation.
HELP_EOF
}

show_version() {
    echo "Suitey v0.1.0"
    echo "Build system functional - ready for implementation"
}

# Run all environment validation checks
# Returns 0 if all checks pass, 1 if any check fails
run_environment_checks() {
    local check_failed=0

    # Run all environment checks
    if ! check_bash_version; then
        check_failed=1
    fi

    if ! check_docker_installed; then
        check_failed=1
    fi

    if ! check_docker_daemon_running; then
        check_failed=1
    fi

    if ! check_tmp_writable; then
        check_failed=1
    fi

    # Return failure if any check failed
    if [[ $check_failed -eq 1 ]]; then
        return 1
    fi

    return 0
}

# Validate and normalize directory path
# Returns normalized absolute path on success, exits with error on failure
validate_directory() {
    local dir_path="$1"
    local original_path="$1"
    
    # Check if directory exists first (before normalization)
    if [[ ! -e "$dir_path" ]]; then
        echo "Error: Directory does not exist: $original_path" >&2
        echo "Run '$0 --help' for usage information." >&2
        return 1
    fi
    
    # Check if it's actually a directory (not a file)
    if [[ ! -d "$dir_path" ]]; then
        echo "Error: Path is not a directory: $original_path" >&2
        echo "Run '$0 --help' for usage information." >&2
        return 1
    fi
    
    # Normalize path: resolve to absolute path
    # Use cd to resolve symlinks and normalize . and ..
    local normalized_path
    if normalized_path="$(cd "$dir_path" 2>/dev/null && pwd)"; then
        dir_path="$normalized_path"
    else
        # If cd failed, try to construct absolute path
        if [[ "$dir_path" != /* ]]; then
            # Relative path - make absolute
            dir_path="$(pwd)/$dir_path"
        fi
    fi
    
    # Check if directory is readable
    if [[ ! -r "$dir_path" ]]; then
        echo "Error: Directory is not readable: $original_path" >&2
        echo "Run '$0 --help' for usage information." >&2
        return 1
    fi
    
    # Return normalized absolute path
    echo "$dir_path"
    return 0
}

main() {
    local target_directory=""
    
    # Parse command-line arguments
    # Options take precedence over directory arguments
    while [[ $# -gt 0 ]]; do
        case "$1" in
            -h|--help)
                show_help
                exit $EXIT_SUCCESS
                ;;
            -v|--version)
                show_version
                exit $EXIT_SUCCESS
                ;;
            -*)
                # Unknown option
                echo "Error: Unknown option '$1'" >&2
                echo "Run '$0 --help' for usage information." >&2
                exit $EXIT_SUITEY_ERROR
                ;;
            *)
                # Non-option argument - treat as directory
                if [[ -n "$target_directory" ]]; then
                    echo "Error: Multiple directory arguments provided. Please specify only one directory." >&2
                    echo "Run '$0 --help' for usage information." >&2
                    exit $EXIT_SUITEY_ERROR
                fi
                target_directory="$1"
                ;;
        esac
        shift
    done
    
    # If no arguments provided, show help
    if [[ -z "$target_directory" ]]; then
        show_help
        exit $EXIT_SUCCESS
    fi
    
    # Validate directory
    local normalized_dir
    normalized_dir=$(validate_directory "$target_directory")
    if [[ $? -ne 0 ]]; then
        exit $EXIT_SUITEY_ERROR
    fi
    
    # Run environment checks before execution
    if ! run_environment_checks; then
        echo "" >&2
        echo "Environment validation failed. Please fix the issues above and try again." >&2
        exit $EXIT_SUITEY_ERROR
    fi
    
    # Register built-in modules
    # These are the core language and framework modules included in the bundle
    if [[ -f "mod/languages/rust/mod.sh" ]]; then
        source "mod/languages/rust/mod.sh" 2>/dev/null || true
        register_module "rust-module" "rust-module" 2>/dev/null || true
    fi

    if [[ -f "mod/languages/bash/mod.sh" ]]; then
        source "mod/languages/bash/mod.sh" 2>/dev/null || true
        register_module "bash-module" "bash-module" 2>/dev/null || true
    fi

    if [[ -f "mod/frameworks/cargo/mod.sh" ]]; then
        source "mod/frameworks/cargo/mod.sh" 2>/dev/null || true
        register_module "cargo-module" "cargo-module" 2>/dev/null || true
    fi

    if [[ -f "mod/frameworks/bats/mod.sh" ]]; then
        source "mod/frameworks/bats/mod.sh" 2>/dev/null || true
        register_module "bats-module" "bats-module" 2>/dev/null || true
    fi

    # Perform platform detection
    echo "Suitey v0.1.0"
    echo "Analyzing project: $normalized_dir"
    echo ""

    # Detect platforms in the target directory
    local detection_results
    detection_results=$(detect_platforms "$normalized_dir" 2>/dev/null || echo "platforms_count=0")

    # Display container environment status
    echo "Container Environment:"
    if echo "$detection_results" | grep -q "docker_command_available=true"; then
        echo "  ✓ Docker command available"
    else
        echo "  ✗ Docker command not found"
    fi

    if echo "$detection_results" | grep -q "docker_daemon_available=true"; then
        echo "  ✓ Docker daemon running"
    else
        echo "  ✗ Docker daemon not accessible"
    fi

    if echo "$detection_results" | grep -q "container_operations=true"; then
        echo "  ✓ Container operations functional"
    else
        echo "  ✗ Container operations failed"
    fi

    if echo "$detection_results" | grep -q "network_access=true"; then
        echo "  ✓ Network access available"
    else
        echo "  ✗ Network access issues"
    fi

    # Display warnings if any
    local warning_count
    warning_count=$(echo "$detection_results" | grep "^docker_warnings_count=" | cut -d'=' -f2)
    if [[ "$warning_count" -gt 0 ]]; then
        echo ""
        echo "Warnings:"
        local i=0
        while [[ $i -lt "$warning_count" ]]; do
            local warning
            warning=$(echo "$detection_results" | grep "^docker_warnings_${i}=" | cut -d'=' -f2-)
            if [[ -n "$warning" ]]; then
                echo "  ⚠ $warning"
            fi
            ((i++))
        done
    fi

    echo ""
    echo "Platform Detection:"

    # Get platform count
    local platforms_count
    platforms_count=$(echo "$detection_results" | grep "^platforms_count=" | cut -d'=' -f2)

    if [[ "$platforms_count" -eq 0 ]]; then
        echo "  No supported platforms detected in this project."
        echo ""
        echo "Supported platforms:"
        echo "  - Rust (Cargo.toml projects)"
        echo "  - Bash (BATS test projects)"
        exit $EXIT_SUCCESS
    fi

    # Display detected platforms
    # Collect unique language+framework combinations with highest confidence
    local detected_projects=""
    local i=0
    while [[ $i -lt "$platforms_count" ]]; do
        local language
        local framework
        local confidence
        local module_type

        language=$(echo "$detection_results" | grep "^platforms_${i}_language=" | head -1 | cut -d'=' -f2)
        framework=$(echo "$detection_results" | grep "^platforms_${i}_framework=" | head -1 | cut -d'=' -f2)
        confidence=$(echo "$detection_results" | grep "^platforms_${i}_confidence=" | head -1 | cut -d'=' -f2)
        module_type=$(echo "$detection_results" | grep "^platforms_${i}_module_type=" | head -1 | cut -d'=' -f2)

        if [[ -n "$language" ]]; then
            local project_key="$language"
            if [[ -n "$framework" ]]; then
                project_key="$project_key-$framework"
            fi

            # Check if we already have this project combination
            if ! echo "$detected_projects" | grep -q "^$project_key:"; then
                # New project combination
                detected_projects="${detected_projects}$project_key:$confidence:$framework"$'\n'
                echo "  ✓ $language project detected (confidence: $confidence)"
                if [[ -n "$framework" ]]; then
                    echo "    Framework: $framework"
                fi
            fi
        fi

        ((i++))
    done

    echo ""
    echo "Full workflow execution will be implemented in future phases."
    exit $EXIT_SUCCESS
}

# Run main function
main "$@"
